import React, { useState, useMemo } from "react";
import {
  Truck, MessageSquare, MapPin, Users, Bell, LogOut, ShieldCheck,
  CheckCircle2, Clock, AlertTriangle, Megaphone, DollarSign,
  Package, KeyRound, Activity, Send, Plus, Search, X, ChevronRight
} from "lucide-react";

/* ---------------------------------------------------------------
   MLSN OPS — palette
   ink #1E1B2E  paper #FAF7F2  plum #4B1F77  violet #7C3AED
   sun #D97706  leaf #16A34A  rose #DC2626  mist #EFE9F8
----------------------------------------------------------------*/

const ROLES = [
  "Supervisor",
  "Admin Assistant",
  "Cashier",
  "Accounting",
  "Warehouse Supervisor",
  "Warehouse Staff",
  "Customer",
];

const seedAccounts = () => {
  const list = [
    { id: "sup1", name: "Liza Domingo", role: "Supervisor", username: "supervisor" },
    { id: "adm1", name: "Mara Santos", role: "Admin Assistant", username: "admin1" },
    { id: "csh1", name: "Jay Cruz", role: "Cashier", username: "cashier1" },
    { id: "acc1", name: "Pia Reyes", role: "Accounting", username: "accounting1" },
    { id: "wsup1", name: "Boy Aquino", role: "Warehouse Supervisor", username: "whsupervisor" },
  ];
  for (let i = 1; i <= 10; i++) {
    list.push({ id: `wh${i}`, name: `Warehouse Staff ${i}`, role: "Warehouse Staff", username: `whstaff${i}` });
  }
  list.push({ id: "cus1", name: "Mildred Tubilla", role: "Customer", username: "customer1" });
  list.push({ id: "cus2", name: "Renz Ormoc", role: "Customer", username: "customer2" });

  return list.map((a) => ({
    ...a,
    password: "1234",
    status: "Active",
    lastActive: "Not yet logged in",
    activity: [{ t: "Account created", at: "System setup" }],
  }));
};

const seedOrders = () => [
  { id: "ORD-1042", customer: "Mildred Tubilla", item: "Inasal Express cart unit", mode: "Lalamove", status: "Preparing", eta: "—", flagged: false, assignedTo: null },
  { id: "ORD-1043", customer: "Renz Ormoc", item: "Purple Blend franchise kit", mode: "Bus (Ormoc)", status: "Unknown", eta: "—", flagged: true, assignedTo: null },
  { id: "ORD-1044", customer: "Grace Pal", item: "Signage + supplies", mode: "Lalamove", status: "Out for delivery", eta: "Today, 4:30 PM", flagged: false, assignedTo: "Warehouse Staff 3" },
  { id: "ORD-1045", customer: "Noel Bautista", item: "Inasal Express cart unit", mode: "Bus (Iloilo)", status: "Delayed", eta: "Tomorrow, AM", flagged: true, assignedTo: "Warehouse Staff 7" },
];

const seedMessages = () => ({
  ORD1042: [{ from: "customer", text: "Hi, any update on my cart unit?" }],
  ORD1043: [{ from: "customer", text: "It's been a week, wala pa pong update 😞" }],
});

const seedAnnouncements = () => [
  { id: 1, by: "Liza Domingo (Supervisor)", text: "Reminder: log out at end of shift. Password resets go through Supervisor only.", time: "Today, 8:02 AM" },
  { id: 2, by: "Mara Santos (Admin Assistant)", text: "New Lalamove rate update effective this week — please confirm fares before marking out for delivery.", time: "Yesterday, 5:40 PM" },
];

const seedEvents = () => [
  { id: 1, event: "Manila Food Expo", item: "Inasal Express franchise pack", amount: 25000, time: "10:14 AM" },
];

const seedExpenses = () => [
  { id: 1, label: "Lalamove fares (weekly)", amount: 3200 },
  { id: 2, label: "Warehouse supplies", amount: 1500 },
];

function StatusPill({ status }) {
  const map = {
    Unknown: "bg-rose-100 text-rose-700 border-rose-200",
    Preparing: "bg-amber-100 text-amber-700 border-amber-200",
    "Out for delivery": "bg-violet-100 text-violet-700 border-violet-200",
    Delivered: "bg-emerald-100 text-emerald-700 border-emerald-200",
    Delayed: "bg-rose-100 text-rose-700 border-rose-200",
  };
  return (
    <span className={`text-xs font-medium px-2.5 py-1 rounded-full border ${map[status] || "bg-stone-100 text-stone-600 border-stone-200"}`}>
      {status}
    </span>
  );
}

function Card({ title, icon, children, right }) {
  return (
    <div className="bg-white rounded-2xl border border-[#EAE3F5] shadow-sm">
      <div className="flex items-center justify-between px-5 py-4 border-b border-[#F1ECFA]">
        <div className="flex items-center gap-2 text-[#3A1763] font-semibold">
          {icon}
          <span>{title}</span>
        </div>
        {right}
      </div>
      <div className="p-5">{children}</div>
    </div>
  );
}

function SectionLabel({ children }) {
  return <div className="text-[11px] uppercase tracking-wider text-[#8B7AAE] font-semibold mb-2">{children}</div>;
}

/* ---------------- LOGIN ---------------- */

function Login({ accounts, onLogin }) {
  const [role, setRole] = useState("Admin Assistant");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const roleAccounts = accounts.filter((a) => a.role === role);

  const submit = (e) => {
    e.preventDefault();
    const acc = accounts.find((a) => a.username === username.trim().toLowerCase());
    if (!acc) return setError("No account found with that username.");
    if (acc.role !== role) return setError(`That username belongs to ${acc.role}, not ${role}.`);
    if (acc.status === "Inactive") return setError("This account has been deactivated by a Supervisor.");
    if (acc.password !== password) return setError("Incorrect password.");
    setError("");
    onLogin(acc);
  };

  return (
    <div className="min-h-screen bg-[#FAF7F2] flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-[#4B1F77] text-white font-bold text-xl mb-3">M</div>
          <h1 className="text-2xl font-bold text-[#2D1450]">MLSN Ops Portal</h1>
          <p className="text-sm text-[#8B7AAE] mt-1">MLSN Franchising Solution Corporation · "Your Plan, Our Goal"</p>
        </div>

        <form onSubmit={submit} className="bg-white rounded-2xl border border-[#EAE3F5] shadow-sm p-6 space-y-4">
          <div>
            <label className="text-xs font-semibold text-[#5B3E8C] block mb-1.5">Role</label>
            <select
              value={role}
              onChange={(e) => { setRole(e.target.value); setUsername(""); setError(""); }}
              className="w-full border border-[#E1D7F2] rounded-xl px-3 py-2.5 text-sm bg-[#FBF9FE] focus:outline-none focus:ring-2 focus:ring-[#7C3AED]"
            >
              {ROLES.map((r) => <option key={r}>{r}</option>)}
            </select>
          </div>

          <div>
            <label className="text-xs font-semibold text-[#5B3E8C] block mb-1.5">Username</label>
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder={roleAccounts[0]?.username || "username"}
              className="w-full border border-[#E1D7F2] rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#7C3AED]"
            />
            <p className="text-[11px] text-[#A89BC4] mt-1">
              Try: {roleAccounts.slice(0, 3).map((a) => a.username).join(", ")}{roleAccounts.length > 3 ? "…" : ""}
            </p>
          </div>

          <div>
            <label className="text-xs font-semibold text-[#5B3E8C] block mb-1.5">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="1234"
              className="w-full border border-[#E1D7F2] rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#7C3AED]"
            />
          </div>

          {error && (
            <div className="text-sm text-rose-600 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2 flex items-center gap-2">
              <AlertTriangle size={14} /> {error}
            </div>
          )}

          <button type="submit" className="w-full bg-[#4B1F77] hover:bg-[#3A1763] text-white font-semibold rounded-xl py-2.5 text-sm transition-colors">
            Log in
          </button>
          <p className="text-center text-[11px] text-[#A89BC4]">Default password for every account is 1234.</p>
        </form>
      </div>
    </div>
  );
}

/* ---------------- SHARED SHELL ---------------- */

function Shell({ account, onLogout, children, sidebar }) {
  return (
    <div className="min-h-screen bg-[#FAF7F2]">
      <header className="bg-[#4B1F77] text-white">
        <div className="max-w-6xl mx-auto px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center font-bold">M</div>
            <div>
              <div className="font-semibold leading-tight">MLSN Ops Portal</div>
              <div className="text-xs text-violet-200 leading-tight">{account.name} · {account.role}</div>
            </div>
          </div>
          <button onClick={onLogout} className="flex items-center gap-1.5 text-sm bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-lg transition-colors">
            <LogOut size={15} /> Log out
          </button>
        </div>
      </header>
      <div className="max-w-6xl mx-auto px-5 py-6 grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-5">
        <div className="space-y-5">{children}</div>
        <div className="space-y-5">{sidebar}</div>
      </div>
    </div>
  );
}

function AnnouncementsPanel({ announcements, canPost, onPost }) {
  const [text, setText] = useState("");
  return (
    <Card title="Notifications & Announcements" icon={<Megaphone size={17} />}>
      {canPost && (
        <div className="mb-4 flex gap-2">
          <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Post an update for everyone…"
            className="flex-1 border border-[#E1D7F2] rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#7C3AED]" />
          <button onClick={() => { if (text.trim()) { onPost(text.trim()); setText(""); } }}
            className="bg-[#4B1F77] text-white rounded-lg px-3 text-sm font-medium hover:bg-[#3A1763]">Post</button>
        </div>
      )}
      <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
        {announcements.map((a) => (
          <div key={a.id} className="text-sm border-l-2 border-[#7C3AED] pl-3">
            <p className="text-[#2D1450]">{a.text}</p>
            <p className="text-[11px] text-[#A89BC4] mt-0.5">{a.by} · {a.time}</p>
          </div>
        ))}
        {announcements.length === 0 && <p className="text-sm text-[#A89BC4]">No announcements yet.</p>}
      </div>
    </Card>
  );
}

/* ---------------- SUPERVISOR ---------------- */

function SupervisorDashboard({ accounts, setAccounts, announcements, postAnnouncement, log }) {
  const [resetTarget, setResetTarget] = useState(null);
  const [search, setSearch] = useState("");

  const filtered = accounts.filter((a) =>
    a.name.toLowerCase().includes(search.toLowerCase()) || a.role.toLowerCase().includes(search.toLowerCase())
  );

  const toggleStatus = (id) => {
    setAccounts((prev) => prev.map((a) => {
      if (a.id !== id) return a;
      const next = a.status === "Active" ? "Inactive" : "Active";
      log(id, `Status changed to ${next} by Supervisor`);
      return { ...a, status: next };
    }));
  };

  const resetPassword = (id) => {
    setAccounts((prev) => prev.map((a) => {
      if (a.id !== id) return a;
      log(id, "Password reset to default (1234) by Supervisor");
      return { ...a, password: "1234" };
    }));
    setResetTarget(null);
  };

  return (
    <>
      <Card title="All Accounts — Master View" icon={<ShieldCheck size={17} />} right={
        <div className="flex items-center gap-2 bg-[#FBF9FE] border border-[#E1D7F2] rounded-lg px-2.5 py-1.5">
          <Search size={14} className="text-[#A89BC4]" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search role or name"
            className="text-sm bg-transparent focus:outline-none w-40" />
        </div>
      }>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] uppercase tracking-wide text-[#8B7AAE] border-b border-[#F1ECFA]">
                <th className="py-2 pr-3">Name</th>
                <th className="py-2 pr-3">Role</th>
                <th className="py-2 pr-3">Username</th>
                <th className="py-2 pr-3">Status</th>
                <th className="py-2 pr-3">Last Activity</th>
                <th className="py-2 pr-3"></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((a) => (
                <tr key={a.id} className="border-b border-[#F6F2FB]">
                  <td className="py-2.5 pr-3 font-medium text-[#2D1450]">{a.name}</td>
                  <td className="py-2.5 pr-3 text-[#5B3E8C]">{a.role}</td>
                  <td className="py-2.5 pr-3 text-[#8B7AAE]">{a.username}</td>
                  <td className="py-2.5 pr-3">
                    <button onClick={() => toggleStatus(a.id)}>
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-full border ${a.status === "Active" ? "bg-emerald-100 text-emerald-700 border-emerald-200" : "bg-stone-100 text-stone-500 border-stone-200"}`}>
                        {a.status}
                      </span>
                    </button>
                  </td>
                  <td className="py-2.5 pr-3 text-[#A89BC4] text-xs">{a.activity[a.activity.length - 1]?.t}</td>
                  <td className="py-2.5 pr-3">
                    <button onClick={() => setResetTarget(a)} className="text-xs flex items-center gap-1 text-[#7C3AED] hover:text-[#4B1F77] font-medium">
                      <KeyRound size={13} /> Reset
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card title="Activity Log" icon={<Activity size={17} />}>
        <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
          {accounts.flatMap((a) => a.activity.map((act, i) => ({ ...act, name: a.name, role: a.role, key: `${a.id}-${i}` })))
            .reverse().slice(0, 12).map((act) => (
              <div key={act.key} className="text-sm flex items-center justify-between border-b border-[#F6F2FB] pb-2">
                <span className="text-[#2D1450]">{act.name} <span className="text-[#A89BC4]">({act.role})</span></span>
                <span className="text-[#8B7AAE] text-xs">{act.t}</span>
              </div>
            ))}
        </div>
      </Card>

      {resetTarget && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full">
            <h3 className="font-semibold text-[#2D1450] mb-2">Reset password</h3>
            <p className="text-sm text-[#5B3E8C] mb-4">Reset <b>{resetTarget.name}</b>'s password back to the default (1234)?</p>
            <div className="flex gap-2 justify-end">
              <button onClick={() => setResetTarget(null)} className="text-sm px-3 py-1.5 rounded-lg border border-[#E1D7F2] text-[#5B3E8C]">Cancel</button>
              <button onClick={() => resetPassword(resetTarget.id)} className="text-sm px-3 py-1.5 rounded-lg bg-[#4B1F77] text-white font-medium">Reset</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

/* ---------------- ADMIN ASSISTANT ---------------- */

function AdminDashboard({ orders, setOrders, messages, setMessages, customers, setCustomers }) {
  const [activeChat, setActiveChat] = useState(Object.keys(messages)[0] || null);
  const [draft, setDraft] = useState("");
  const [form, setForm] = useState({ name: "", address: "", contact: "" });
  const [pin, setPin] = useState(null);

  const flagged = orders.filter((o) => o.flagged);

  const sendMessage = () => {
    if (!draft.trim() || !activeChat) return;
    setMessages((prev) => ({ ...prev, [activeChat]: [...(prev[activeChat] || []), { from: "admin", text: draft.trim() }] }));
    setDraft("");
  };

  const findPin = (e) => {
    e.preventDefault();
    if (!form.address.trim()) return;
    const lat = (14.5 + Math.random() * 0.6).toFixed(5);
    const lng = (120.9 + Math.random() * 0.6).toFixed(5);
    setPin({ lat, lng });
    setCustomers((prev) => [...prev, { ...form, lat, lng, id: Date.now() }]);
    setForm({ name: "", address: "", contact: "" });
  };

  return (
    <>
      {flagged.length > 0 && (
        <Card title="Needs attention now" icon={<AlertTriangle size={17} className="text-amber-600" />}>
          <div className="space-y-2">
            {flagged.map((o) => (
              <div key={o.id} className="flex items-center justify-between bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 text-sm">
                <span className="text-amber-800 font-medium">{o.id} — {o.customer}: delivery status is "{o.status}", give an update today.</span>
              </div>
            ))}
          </div>
        </Card>
      )}

      <Card title="Delivery Tracker" icon={<Truck size={17} />}>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] uppercase tracking-wide text-[#8B7AAE] border-b border-[#F1ECFA]">
                <th className="py-2 pr-3">Order</th><th className="py-2 pr-3">Customer</th>
                <th className="py-2 pr-3">Mode</th><th className="py-2 pr-3">Status</th>
                <th className="py-2 pr-3">ETA</th><th className="py-2 pr-3">Assigned</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.id} className="border-b border-[#F6F2FB]">
                  <td className="py-2.5 pr-3 font-medium text-[#2D1450]">{o.id}</td>
                  <td className="py-2.5 pr-3">{o.customer}</td>
                  <td className="py-2.5 pr-3 text-[#5B3E8C]">{o.mode}</td>
                  <td className="py-2.5 pr-3"><StatusPill status={o.status} /></td>
                  <td className="py-2.5 pr-3 text-[#8B7AAE]">{o.eta}</td>
                  <td className="py-2.5 pr-3 text-[#8B7AAE]">{o.assignedTo || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card title="Customer chat" icon={<MessageSquare size={17} />}>
        <div className="grid grid-cols-[140px_1fr] gap-4">
          <div className="space-y-1">
            {Object.keys(messages).map((k) => (
              <button key={k} onClick={() => setActiveChat(k)}
                className={`w-full text-left text-sm px-2.5 py-2 rounded-lg ${activeChat === k ? "bg-[#EFE9F8] text-[#3A1763] font-medium" : "text-[#5B3E8C] hover:bg-[#FBF9FE]"}`}>
                {k}
              </button>
            ))}
          </div>
          <div>
            <div className="border border-[#F1ECFA] rounded-xl p-3 h-44 overflow-y-auto space-y-2 mb-2">
              {(messages[activeChat] || []).map((m, i) => (
                <div key={i} className={`text-sm max-w-[80%] px-3 py-1.5 rounded-xl ${m.from === "admin" ? "bg-[#4B1F77] text-white ml-auto" : "bg-[#F1ECFA] text-[#2D1450]"}`}>
                  {m.text}
                </div>
              ))}
              {!activeChat && <p className="text-sm text-[#A89BC4]">Select a conversation.</p>}
            </div>
            <div className="flex gap-2">
              <input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Reply to customer…"
                className="flex-1 border border-[#E1D7F2] rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#7C3AED]" />
              <button onClick={sendMessage} className="bg-[#4B1F77] text-white rounded-lg px-3 hover:bg-[#3A1763]"><Send size={15} /></button>
            </div>
          </div>
        </div>
      </Card>

      <Card title="Customer info & nearest delivery pin" icon={<MapPin size={17} />}>
        <form onSubmit={findPin} className="grid sm:grid-cols-3 gap-2 mb-3">
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Customer name"
            className="border border-[#E1D7F2] rounded-lg px-3 py-2 text-sm" />
          <input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} placeholder="Delivery address"
            className="border border-[#E1D7F2] rounded-lg px-3 py-2 text-sm" />
          <div className="flex gap-2">
            <input value={form.contact} onChange={(e) => setForm({ ...form, contact: e.target.value })} placeholder="Contact no."
              className="border border-[#E1D7F2] rounded-lg px-3 py-2 text-sm flex-1" />
            <button className="bg-[#4B1F77] text-white rounded-lg px-3 text-sm font-medium">Pin</button>
          </div>
        </form>
        {pin && <p className="text-xs text-[#7C3AED] mb-3">Nearest pin found: {pin.lat}, {pin.lng}</p>}
        <div className="space-y-1.5 max-h-40 overflow-y-auto">
          {customers.map((c) => (
            <div key={c.id} className="text-sm flex justify-between border-b border-[#F6F2FB] pb-1.5">
              <span className="text-[#2D1450]">{c.name} · {c.address}</span>
              <span className="text-[#A89BC4] text-xs">{c.lat}, {c.lng}</span>
            </div>
          ))}
        </div>
      </Card>
    </>
  );
}

/* ---------------- WAREHOUSE SUPERVISOR ---------------- */

function WarehouseSupervisorDashboard({ accounts, orders, setOrders }) {
  const staff = accounts.filter((a) => a.role === "Warehouse Staff");
  const assign = (orderId, staffName) => {
    setOrders((prev) => prev.map((o) => o.id === orderId ? { ...o, assignedTo: staffName } : o));
  };
  return (
    <>
      <Card title="Warehouse staff status" icon={<Users size={17} />}>
        <div className="grid sm:grid-cols-2 gap-2">
          {staff.map((s) => (
            <div key={s.id} className="flex items-center justify-between border border-[#F1ECFA] rounded-lg px-3 py-2 text-sm">
              <span className="text-[#2D1450]">{s.name}</span>
              <span className={`text-xs px-2 py-0.5 rounded-full border ${s.status === "Active" ? "bg-emerald-100 text-emerald-700 border-emerald-200" : "bg-stone-100 text-stone-500 border-stone-200"}`}>{s.status}</span>
            </div>
          ))}
        </div>
      </Card>
      <Card title="Assign deliveries" icon={<Package size={17} />}>
        <div className="space-y-2">
          {orders.map((o) => (
            <div key={o.id} className="flex items-center justify-between border-b border-[#F6F2FB] pb-2 text-sm">
              <div>
                <span className="font-medium text-[#2D1450]">{o.id}</span> — {o.customer} <StatusPill status={o.status} />
              </div>
              <select value={o.assignedTo || ""} onChange={(e) => assign(o.id, e.target.value)}
                className="border border-[#E1D7F2] rounded-lg px-2 py-1 text-xs">
                <option value="">Unassigned</option>
                {staff.map((s) => <option key={s.id} value={s.name}>{s.name}</option>)}
              </select>
            </div>
          ))}
        </div>
      </Card>
    </>
  );
}

/* ---------------- WAREHOUSE STAFF ---------------- */

function WarehouseStaffDashboard({ account, orders, setOrders }) {
  const myOrders = orders.filter((o) => o.assignedTo === account.name);
  const update = (id, status, eta, mode) => {
    setOrders((prev) => prev.map((o) => o.id === id ? { ...o, status, eta: eta || o.eta, mode: mode || o.mode, flagged: false } : o));
  };
  return (
    <Card title="My assigned deliveries" icon={<Truck size={17} />}>
      {myOrders.length === 0 && <p className="text-sm text-[#A89BC4]">No deliveries assigned to you yet.</p>}
      <div className="space-y-3">
        {myOrders.map((o) => (
          <div key={o.id} className="border border-[#F1ECFA] rounded-xl p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium text-[#2D1450]">{o.id} — {o.customer}</span>
              <StatusPill status={o.status} />
            </div>
            <div className="flex flex-wrap gap-2 text-sm">
              <select defaultValue={o.mode} onChange={(e) => update(o.id, o.status, null, e.target.value)} className="border border-[#E1D7F2] rounded-lg px-2 py-1.5 text-xs">
                <option>Lalamove</option><option>Bus (Ormoc)</option><option>Bus (Iloilo)</option><option>Pickup</option>
              </select>
              <input placeholder="ETA e.g. Today, 4PM" defaultValue={o.eta === "—" ? "" : o.eta}
                onBlur={(e) => update(o.id, o.status, e.target.value, null)}
                className="border border-[#E1D7F2] rounded-lg px-2 py-1.5 text-xs flex-1 min-w-[140px]" />
              <button onClick={() => update(o.id, "Out for delivery")} className="bg-violet-100 text-violet-700 px-2.5 py-1.5 rounded-lg text-xs font-medium">Mark out for delivery</button>
              <button onClick={() => update(o.id, "Delivered")} className="bg-emerald-100 text-emerald-700 px-2.5 py-1.5 rounded-lg text-xs font-medium">Mark delivered</button>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

/* ---------------- CASHIER ---------------- */

function CashierDashboard({ events, setEvents }) {
  const [form, setForm] = useState({ event: "", item: "", amount: "" });
  const total = events.reduce((s, e) => s + e.amount, 0);
  const add = (e) => {
    e.preventDefault();
    if (!form.event || !form.amount) return;
    setEvents((prev) => [...prev, { id: Date.now(), event: form.event, item: form.item, amount: Number(form.amount), time: new Date().toLocaleTimeString() }]);
    setForm({ event: "", item: "", amount: "" });
  };
  return (
    <Card title="Event sales" icon={<DollarSign size={17} />} right={<span className="text-sm font-semibold text-[#4B1F77]">Total: ₱{total.toLocaleString()}</span>}>
      <form onSubmit={add} className="grid sm:grid-cols-4 gap-2 mb-4">
        <input value={form.event} onChange={(e) => setForm({ ...form, event: e.target.value })} placeholder="Event name" className="border border-[#E1D7F2] rounded-lg px-3 py-2 text-sm" />
        <input value={form.item} onChange={(e) => setForm({ ...form, item: e.target.value })} placeholder="Item sold" className="border border-[#E1D7F2] rounded-lg px-3 py-2 text-sm" />
        <input value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} placeholder="Amount ₱" type="number" className="border border-[#E1D7F2] rounded-lg px-3 py-2 text-sm" />
        <button className="bg-[#4B1F77] text-white rounded-lg px-3 text-sm font-medium flex items-center justify-center gap-1"><Plus size={14} /> Add sale</button>
      </form>
      <div className="space-y-1.5">
        {events.map((e) => (
          <div key={e.id} className="flex justify-between text-sm border-b border-[#F6F2FB] pb-1.5">
            <span className="text-[#2D1450]">{e.event} — {e.item}</span>
            <span className="text-[#5B3E8C]">₱{e.amount.toLocaleString()} <span className="text-[#A89BC4] text-xs">{e.time}</span></span>
          </div>
        ))}
      </div>
    </Card>
  );
}

/* ---------------- ACCOUNTING ---------------- */

function AccountingDashboard({ events, expenses, setExpenses }) {
  const income = events.reduce((s, e) => s + e.amount, 0);
  const spent = expenses.reduce((s, e) => s + e.amount, 0);
  const [form, setForm] = useState({ label: "", amount: "" });
  const add = (e) => {
    e.preventDefault();
    if (!form.label || !form.amount) return;
    setExpenses((prev) => [...prev, { id: Date.now(), label: form.label, amount: Number(form.amount) }]);
    setForm({ label: "", amount: "" });
  };
  return (
    <>
      <Card title="Financial summary" icon={<DollarSign size={17} />}>
        <div className="grid sm:grid-cols-3 gap-3">
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3"><SectionLabel>Income (events)</SectionLabel><p className="text-xl font-bold text-emerald-700">₱{income.toLocaleString()}</p></div>
          <div className="bg-rose-50 border border-rose-200 rounded-xl p-3"><SectionLabel>Expenses</SectionLabel><p className="text-xl font-bold text-rose-700">₱{spent.toLocaleString()}</p></div>
          <div className="bg-violet-50 border border-violet-200 rounded-xl p-3"><SectionLabel>Net</SectionLabel><p className="text-xl font-bold text-violet-700">₱{(income - spent).toLocaleString()}</p></div>
        </div>
      </Card>
      <Card title="Record an expense" icon={<Package size={17} />}>
        <form onSubmit={add} className="grid sm:grid-cols-3 gap-2 mb-4">
          <input value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} placeholder="Description" className="border border-[#E1D7F2] rounded-lg px-3 py-2 text-sm" />
          <input value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} placeholder="Amount ₱" type="number" className="border border-[#E1D7F2] rounded-lg px-3 py-2 text-sm" />
          <button className="bg-[#4B1F77] text-white rounded-lg px-3 text-sm font-medium">Add expense</button>
        </form>
        <div className="space-y-1.5">
          {expenses.map((e) => (
            <div key={e.id} className="flex justify-between text-sm border-b border-[#F6F2FB] pb-1.5">
              <span className="text-[#2D1450]">{e.label}</span><span className="text-rose-600">-₱{e.amount.toLocaleString()}</span>
            </div>
          ))}
        </div>
      </Card>
    </>
  );
}

/* ---------------- CUSTOMER ---------------- */

function CustomerDashboard({ account, orders, messages, setMessages }) {
  const myOrder = orders.find((o) => o.customer === account.name) || orders[0];
  const key = myOrder ? myOrder.id.replace("-", "") : null;
  const thread = (key && messages[key]) || [];
  const [draft, setDraft] = useState("");
  const send = () => {
    if (!draft.trim() || !key) return;
    setMessages((prev) => ({ ...prev, [key]: [...(prev[key] || []), { from: "customer", text: draft.trim() }] }));
    setDraft("");
  };
  return (
    <>
      <Card title="My delivery" icon={<Truck size={17} />}>
        {myOrder ? (
          <div className="space-y-1.5 text-sm">
            <p className="text-[#2D1450] font-medium">{myOrder.id} — {myOrder.item}</p>
            <p className="text-[#5B3E8C]">Mode: {myOrder.mode}</p>
            <div className="flex items-center gap-2"><StatusPill status={myOrder.status} /><span className="text-[#8B7AAE]">ETA: {myOrder.eta}</span></div>
          </div>
        ) : <p className="text-sm text-[#A89BC4]">No orders found yet.</p>}
      </Card>
      <Card title="Chat with Admin Assistant" icon={<MessageSquare size={17} />}>
        <div className="border border-[#F1ECFA] rounded-xl p-3 h-44 overflow-y-auto space-y-2 mb-2">
          {thread.map((m, i) => (
            <div key={i} className={`text-sm max-w-[80%] px-3 py-1.5 rounded-xl ${m.from === "customer" ? "bg-[#4B1F77] text-white ml-auto" : "bg-[#F1ECFA] text-[#2D1450]"}`}>{m.text}</div>
          ))}
          {thread.length === 0 && <p className="text-sm text-[#A89BC4]">Say hello to start the conversation.</p>}
        </div>
        <div className="flex gap-2">
          <input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Message admin assistant…"
            className="flex-1 border border-[#E1D7F2] rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#7C3AED]" />
          <button onClick={send} className="bg-[#4B1F77] text-white rounded-lg px-3 hover:bg-[#3A1763]"><Send size={15} /></button>
        </div>
      </Card>
    </>
  );
}

/* ---------------- ROOT APP ---------------- */

export default function App() {
  const [accounts, setAccounts] = useState(seedAccounts);
  const [account, setAccount] = useState(null);
  const [orders, setOrders] = useState(seedOrders);
  const [messages, setMessages] = useState(seedMessages);
  const [customers, setCustomers] = useState([]);
  const [announcements, setAnnouncements] = useState(seedAnnouncements);
  const [events, setEvents] = useState(seedEvents);
  const [expenses, setExpenses] = useState(seedExpenses);

  const log = (id, text) => {
    setAccounts((prev) => prev.map((a) => a.id === id ? { ...a, activity: [...a.activity, { t: text, at: new Date().toLocaleTimeString() }] } : a));
  };

  const handleLogin = (acc) => {
    setAccounts((prev) => prev.map((a) => a.id === acc.id ? { ...a, lastActive: "Logged in just now", activity: [...a.activity, { t: "Logged in", at: new Date().toLocaleTimeString() }] } : a));
    setAccount(acc);
  };

  const handleLogout = () => {
    if (account) log(account.id, "Logged out");
    setAccount(null);
  };

  const postAnnouncement = (text) => {
    setAnnouncements((prev) => [{ id: Date.now(), by: `${account.name} (${account.role})`, text, time: "Just now" }, ...prev]);
  };

  if (!account) return <Login accounts={accounts} onLogin={handleLogin} />;

  const canPost = account.role === "Supervisor" || account.role === "Admin Assistant";

  const sidebar = (
    <AnnouncementsPanel announcements={announcements} canPost={canPost} onPost={postAnnouncement} />
  );

  let main;
  switch (account.role) {
    case "Supervisor":
      main = <SupervisorDashboard accounts={accounts} setAccounts={setAccounts} announcements={announcements} postAnnouncement={postAnnouncement} log={log} />;
      break;
    case "Admin Assistant":
      main = <AdminDashboard orders={orders} setOrders={setOrders} messages={messages} setMessages={setMessages} customers={customers} setCustomers={setCustomers} />;
      break;
    case "Warehouse Supervisor":
      main = <WarehouseSupervisorDashboard accounts={accounts} orders={orders} setOrders={setOrders} />;
      break;
    case "Warehouse Staff":
      main = <WarehouseStaffDashboard account={account} orders={orders} setOrders={setOrders} />;
      break;
    case "Cashier":
      main = <CashierDashboard events={events} setEvents={setEvents} />;
      break;
    case "Accounting":
      main = <AccountingDashboard events={events} expenses={expenses} setExpenses={setExpenses} />;
      break;
    case "Customer":
      main = <CustomerDashboard account={account} orders={orders} messages={messages} setMessages={setMessages} />;
      break;
    default:
      main = <p>No dashboard for this role yet.</p>;
  }

  return <Shell account={account} onLogout={handleLogout} sidebar={sidebar}>{main}</Shell>;
}
